class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:Education%40123@localhost/GroceryManagement'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'your_secret_key'
